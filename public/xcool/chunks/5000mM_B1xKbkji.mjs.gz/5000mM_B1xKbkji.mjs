const data = [
  {
    athlete: "Riccardo Vigneri",
    school: "SSC",
    time: "",
    series: 1
  },
  {
    athlete: "Tommaso Ulian",
    school: "SSDTW",
    time: "",
    series: 1
  },
  {
    athlete: "Leonardo Rossi",
    school: "SSDTW",
    time: "",
    series: 2
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: "",
    series: 1
  },
  {
    athlete: "Federico Rinelli",
    school: "ISUFI",
    time: "",
    series: 1
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: "",
    series: 1
  },
  {
    athlete: "Giuseppe Monaco",
    school: "SSC",
    time: "",
    series: 2
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: "",
    series: 1
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "",
    series: 2
  },
  {
    athlete: "Lorenzo Lo Cascio",
    school: "CSB",
    time: "",
    series: 2
  },
  {
    athlete: "Michele Gomba",
    school: "SSST",
    time: "",
    series: 2
  },
  {
    athlete: "Emilio Ferrante",
    school: "SSSAS",
    time: "",
    series: 2
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: "",
    series: 1
  },
  {
    athlete: "Piersanti Di Stefano",
    school: "SSC",
    time: "",
    series: 2
  },
  {
    athlete: "Stefano Di Iulio",
    school: "SGSS",
    time: "",
    series: 2
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    series: 1
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: "",
    series: 2
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "",
    series: 1
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "",
    series: 1
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: "",
    series: 2
  },
  {
    athlete: "Davide Cicchetti",
    school: "SSSAS",
    time: "",
    series: 2
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: "",
    series: 1
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: "",
    series: 1
  },
  {
    athlete: "Leonardo Alma",
    school: "SSC",
    time: "",
    series: 2
  },
  {
    athlete: "Samuele L. Marino",
    //Libero
    school: "SGSS",
    time: "",
    series: 1
  }
];

export { data };
