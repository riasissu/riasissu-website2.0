const data = [
  /*   {
    athlete: "Giacomo Bortolussi",
    school: "SSDTW",
    time: "",
    lane: "2",
    series: 1,
  }, */
  {
    athlete: "Carlo Castellino",
    school: "SGSS",
    time: "27.31",
    lane: "3",
    series: 1
  },
  {
    athlete: "Nicolò Brunacci",
    school: "SSST",
    time: "31.8",
    lane: "4",
    series: 1
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "DNS",
    lane: "5",
    series: 1
  },
  {
    athlete: "Simone de Angelis",
    school: "CSB",
    time: "DNS",
    lane: "6",
    series: 1
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "DNS",
    lane: "7",
    series: 1
  },
  {
    athlete: "Samuele Lombardo",
    school: "SSC",
    time: "29.06",
    lane: "3",
    series: 2
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "DNS",
    lane: "4",
    series: 2
  },
  {
    athlete: "Dario Sanfilippo",
    school: "SSC",
    time: "52.72",
    lane: "5",
    series: 2
  },
  {
    athlete: "Antonino Volante",
    school: "SSC",
    time: "27.50",
    lane: "6",
    series: 2
  },
  {
    athlete: "Giulio De Musso",
    school: "ISUFI",
    time: "DNS",
    lane: "7",
    series: 2
  },
  {
    athlete: "Paolo Strenghetto",
    school: "SGSS",
    time: "31.81",
    lane: "7",
    series: 2
  }
];

export { data };
