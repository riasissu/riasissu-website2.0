import { jsx, jsxs } from 'react/jsx-runtime';
import { useState, useEffect } from 'react';
import styled from '@emotion/styled';
import { T as Theme } from './Layout_Abjf1cfq.mjs';

const ChartWrapper = styled.div`
  margin-top: 50px;
  margin-left: auto;
  margin-right: auto;
  padding: 24px;
  background: ${Theme.secondary};
  border-radius: 12px;
  width:100%;
  max-width: 960px;
  align-self: center;
`;
const Row = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 16px;
`;
const Label = styled.div`
  flex: 0 0 80px;
  font-size: 14px;
  font-weight: 600;
  color: ${Theme.primary};
  margin-right: 12px;
`;
const BarContainer = styled.div`
  flex: 1;
  background: ${Theme.secondary};
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  height: 20px;
`;
const Bar = styled.div`
  width: ${({ pct }) => pct}%;
  background: #0000ff;
  height: 100%;
  border-radius: 12px 12px 12px 12px;
  transition: width 1s ease-out;
`;
const Value = styled.div`
  position: absolute;
  left: ${({ pct }) => pct}%;
  top: 50%;
  transform: translate(${({ pct }) => pct > 90 ? "-100%,-50%" : "4px,-50%"});
  transition:
    left 1s ease-out,
    transform 1s ease-out;
  font-size: 16px;
  font-weight: 500;
  color: ${Theme.primary};
  white-space: nowrap;
`;
const Icon = styled.img`
  transform: translateY(2px);
`;
function BarChart({ data, icon }) {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    const id = window.setTimeout(() => setLoaded(true), 50);
    return () => window.clearTimeout(id);
  }, []);
  const max = Math.max(...data.map((d) => d.total), 1);
  return /* @__PURE__ */ jsx(ChartWrapper, { children: data.map((d) => {
    const pct = Math.round(d.total / max * 90);
    const displayPct = loaded ? pct : 0;
    return /* @__PURE__ */ jsxs(Row, { children: [
      /* @__PURE__ */ jsx(Label, { children: d.school }),
      /* @__PURE__ */ jsxs(BarContainer, { children: [
        /* @__PURE__ */ jsx(Bar, { pct: displayPct }),
        /* @__PURE__ */ jsxs(Value, { pct: displayPct, children: [
          d.total,
          " ",
          /* @__PURE__ */ jsx(Icon, { width: "18px", src: icon.src })
        ] })
      ] })
    ] }, d.school);
  }) });
}

export { BarChart as B };
