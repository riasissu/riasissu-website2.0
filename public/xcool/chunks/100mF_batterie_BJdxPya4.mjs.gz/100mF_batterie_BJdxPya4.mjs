const data1 = [
  {
    athlete: "Desirè La Manna",
    school: "SSC",
    time: "",
    lane: 2
  },
  {
    athlete: "Francesca M. P. Greco",
    // Maria Piera
    school: "SSC",
    time: "",
    lane: 3
  },
  {
    athlete: "Elena Dichiara",
    school: "SSMC",
    time: "",
    lane: 4
  },
  {
    athlete: "Rachele Dentesani",
    school: "SSDTW",
    time: "",
    lane: 5
  },
  {
    athlete: "Ludovica Giannino",
    school: "SSC",
    time: "",
    lane: 6
  }
];
const data2 = [
  {
    athlete: "Maddalena Feltrin",
    school: "SSDTW",
    time: "",
    lane: 2
  },
  {
    athlete: "Maria Elena Arrigo",
    school: "SSC",
    time: "",
    lane: 3
  },
  {
    athlete: "Eleonora Cannella",
    school: "SSC",
    time: "",
    lane: 4
  },
  {
    athlete: "Chiara Fantin",
    school: "SGSS",
    time: "",
    lane: 5
  },
  {
    athlete: "Carla Migliorisi",
    school: "SSC",
    time: "",
    lane: 6
  }
];
const data3 = [
  {
    athlete: "Giulia M. Giacchetto",
    //Maria
    school: "SSDTW",
    time: "",
    lane: 2
  },
  {
    athlete: "Alice Nanni",
    school: "SSSAS",
    time: "",
    lane: 3
  },
  {
    athlete: "Francesca Ciocchi",
    school: "SGSS",
    time: "",
    lane: 4
  },
  {
    athlete: "Arianna Pedone",
    school: "SSC",
    time: "",
    lane: 5
  }
];

export { data1, data2, data3 };
