const data = [
  /*   {
    athlete: "Giacomo Bortolussi",
    school: "SSDTW",
    time: "",
    lane: "2",
    series: 1,
  }, */
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    lane: "3",
    series: 1
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "",
    lane: "4",
    series: 1
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: "",
    lane: "5",
    series: 1
  },
  {
    athlete: "Nicolò Brunacci",
    school: "SSST",
    time: "",
    lane: "6",
    series: 1
  },
  {
    athlete: "Samuele Lombardo",
    school: "SSC",
    time: "",
    lane: "2",
    series: 2
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "",
    lane: "3",
    series: 2
  },
  {
    athlete: "Dario Sanfilippo",
    school: "SSC",
    time: "",
    lane: "4",
    series: 2
  },
  {
    athlete: "Antonino Volante",
    school: "SSC",
    time: "",
    lane: "5",
    series: 2
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: "",
    lane: "6",
    series: 2
  },
  {
    athlete: "Bruno d’Arrigo",
    school: "SSC",
    time: "",
    lane: "7",
    series: 2
  }
];

export { data };
