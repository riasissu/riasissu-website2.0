const data1 = [
  /* {
     athlete: "Francesco Peroni",
     school: "SGSS",
     lane: 5,
     time: "10.05",
     qualifier: "Q"
  }, */
  {
    athlete: "Santi Fisichella",
    school: "SSC",
    time: "DNS",
    lane: 2
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    time: "11.87",
    lane: 3
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: "DNS",
    lane: 4
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    time: "15.06",
    lane: 4
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: "12.72",
    lane: 5
  }
];
const data2 = [
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: "DNS",
    lane: 2
  },
  {
    athlete: "Gabriele B. Finocchiaro",
    //Bartolomeo
    school: "SSC",
    time: "15.00",
    lane: 3
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: "13.25",
    lane: 4
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: "DNS",
    lane: 5
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "11.65",
    lane: 5
  }
];
const data3 = [
  {
    athlete: "Giulio De Musso",
    school: "ISUFI",
    time: "DNS",
    lane: 2
  },
  /*   {
    athlete: "Giovanni Marzioni",
    school: "SSSAS",
    time: "",
    lane: 2,
  }, */
  {
    athlete: "Lorenzo Montano",
    school: "SSC",
    time: "13.25",
    lane: 3
  },
  /*   {
    athlete: "Tommaso Malpensa",
    school: "CSB",
    time: "",
    lane: 4,
  }, */
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "14.18",
    lane: 4
  },
  {
    athlete: "Gioele Clemente",
    school: "SSDTW",
    time: "12.84",
    lane: 5
  }
];
const data4 = [
  {
    athlete: "Francesco Decataldo",
    school: "SSDTW",
    time: "15.03",
    lane: 2
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    time: "12.78",
    lane: 3
  },
  {
    athlete: "Filippo Troina",
    school: "SSC",
    time: "13.31",
    lane: 4
  },
  {
    athlete: "Nazareno Piccin",
    school: "SSDTW",
    time: "13.57",
    lane: 5
  }
];

export { data1, data2, data3, data4 };
