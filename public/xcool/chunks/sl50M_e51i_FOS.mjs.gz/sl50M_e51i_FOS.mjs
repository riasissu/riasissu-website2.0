const data = [
  {
    athlete: "Giacomo Bortolussi",
    school: "SSDTW",
    time: "",
    lane: "2A"
  },
  {
    athlete: "Carlo Castellino",
    school: "SGSS",
    time: "",
    lane: "3A"
  },
  {
    athlete: "Nicolò Brunacci",
    school: "SSST",
    time: "",
    lane: "4A"
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "",
    lane: "5A"
  },
  {
    athlete: "Simone de Angelis",
    school: "CSB",
    time: "",
    lane: "6A"
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    lane: "7A"
  },
  {
    athlete: "Samuele Lombardo",
    school: "SSC",
    time: "",
    lane: "3B"
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "",
    lane: "4B"
  },
  {
    athlete: "Dario Sanfilippo",
    school: "SSC",
    time: "",
    lane: "5B"
  },
  {
    athlete: "Antonino Volante",
    school: "SSC",
    time: "",
    lane: "6B"
  },
  {
    athlete: "Giulio De Musso",
    school: "ISUFI",
    time: "",
    lane: "7B"
  }
];

export { data };
