const data = [
  {
    athlete: "Lorenzo Montano",
    school: "SSC",
    time: "12.78",
    lane: 1,
    series: 1
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    time: "12.35",
    lane: 2,
    series: 1
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "11.62",
    lane: 3,
    series: 1
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    lane: 4,
    time: "11.81",
    series: 1
  },
  {
    athlete: "Gioele Clemente",
    school: "SSDTW",
    lane: 5,
    time: "12.28",
    series: 1
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    lane: 6,
    time: "12.32",
    series: 1
  },
  {
    athlete: "Nazareno Piccin",
    school: "SSDTW",
    time: "13.25",
    lane: 2,
    series: 2
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    time: "14.97",
    lane: 3,
    series: 2
  },
  {
    athlete: "Filippo Troina",
    school: "SSC",
    time: "13.37",
    lane: 4,
    series: 2
  },
  {
    athlete: "Gabriele B. Finocchiaro",
    //Bartolomeo
    school: "SSC",
    lane: 6,
    time: "15.19",
    series: 2
  }
];

export { data };
