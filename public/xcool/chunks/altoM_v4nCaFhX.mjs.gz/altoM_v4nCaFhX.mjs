const heights = [
  1,
  1.15,
  1.3,
  1.4,
  1.45,
  1.5,
  1.55,
  1.6,
  1.63,
  1.8
];
const data = [
  {
    athlete: "Josè Ruggeri",
    school: "SSC",
    note: "",
    attempts: { "1.00": "XXO", "1.15": "-", "1.30": "O" }
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    note: "",
    attempts: { "1.15": "O", "1.30": "O", "1.40": "O", "1.45": "O", "1.50": "XXX" }
  },
  {
    athlete: "Giovanni Mecenero",
    school: "SGSS",
    note: "",
    attempts: { "1.30": "O", "1.40": "O", "1.45": "-", "1.50": "O", "1.55": "O", "1.60": "O", "1.63": "XXX" }
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    note: "",
    attempts: { "1.00": "O", "1.15": "O", "1.30": "XXX" }
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    note: "",
    attempts: { "1.55": "O", "1.60": "-", "1.63": "O", "1.66": "-", "1.80": "XXX" }
  },
  {
    athlete: "Nicolò Pelizzoli",
    school: "SSDTW",
    note: "",
    attempts: {}
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    note: "",
    attempts: {}
  }
];

export { data, heights };
