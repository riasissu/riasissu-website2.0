const data = [
  {
    athlete: "Filippo Troina",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Lorenzo Montano",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Giovanni  Marzioni",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Matteo Leveque",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Giovanni Gerardo",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Santi  Fisichella",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    time: ""
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: ""
  }
];

export { data };
