const data = [
  {
    athlete: "Alessandro Ruggiero",
    school: "CSB",
    attempts: ["6.85", "X", "-", "7.02"]
  },
  {
    athlete: "Lorenzo Ciaffi",
    school: "CSB",
    attempts: []
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    attempts: []
  },
  {
    athlete: "Alessandro Valota",
    school: "SGSS",
    attempts: []
  },
  {
    athlete: "Luca Castenetto",
    school: "SGSS",
    attempts: []
  },
  {
    athlete: "Samuele Libero Marino",
    school: "SGSS",
    attempts: []
  },
  {
    athlete: "Vittorio Magnaguagno",
    school: "SGSS",
    attempts: []
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    attempts: []
  },
  {
    athlete: "Francesco Decataldo",
    school: "SSDTW",
    attempts: []
  },
  {
    athlete: "Leonardo Danelutti",
    school: "SSDTW",
    attempts: []
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    attempts: []
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    attempts: []
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    attempts: []
  }
];

export { data };
