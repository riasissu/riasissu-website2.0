const down = new Proxy({"src":"/xcool/_astro/down.ZYNO2wrg.png","width":574,"height":303,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/down.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/down.png");
							return target[name];
						}
					});

const next = new Proxy({"src":"/xcool/_astro/next.Dxpry1eZ.png","width":473,"height":307,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/next.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/next.png");
							return target[name];
						}
					});

export { down as d, next as n };
