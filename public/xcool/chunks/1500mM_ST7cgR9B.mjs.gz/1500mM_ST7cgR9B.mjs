const data = [
  {
    athlete: "Federico Rinelli",
    school: "ISUFI",
    time: "",
    series: 1
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: "",
    series: 1
  },
  {
    athlete: "Giuseppe Monaco",
    school: "SSC",
    time: "",
    series: 2
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: "",
    series: 2
  },
  {
    athlete: "Giovanni  Marzioni ",
    school: "SSSAS",
    time: "",
    series: 1
  },
  {
    athlete: "Matteo Leveque",
    school: "SSSAS",
    time: "",
    series: 2
  },
  {
    athlete: "Michele Gomba",
    school: "SSST",
    time: "",
    series: 2
  },
  {
    athlete: "Giovanni Gerardo",
    school: "SGSS",
    time: "",
    series: 2
  },
  {
    athlete: "Santi Fisichella",
    school: "SSC",
    time: "",
    series: 2
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    time: "",
    series: 1
  },
  {
    athlete: "Emilio Ferrante",
    school: "SSSAS",
    time: "",
    series: 2
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: "",
    series: 1
  },
  {
    athlete: "Stefano Di Iulio",
    school: "SGSS",
    time: "",
    series: 1
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    series: 2
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: "",
    series: 1
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "",
    series: 1
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: "",
    series: 1
  },
  {
    athlete: "Davide Cicchetti",
    school: "SSSAS",
    time: "",
    series: 1
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: "",
    series: 1
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: "",
    series: 2
  },
  {
    athlete: "Samuele L. Marino",
    //Libero
    school: "SGSS",
    time: "",
    series: 2
  }
];

export { data };
