const data = [
  /*   {
    athlete: "Giacomo Bortolussi",
    school: "SSDTW",
    time: "",
    lane: "2",
    series: 1,
  }, */
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "DNS",
    lane: "3",
    series: 1
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "DNF",
    lane: "4",
    series: 1
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: "3:22.56",
    lane: "5",
    series: 1
  },
  {
    athlete: "Nicolò Brunacci",
    school: "SSST",
    time: "3:03.97",
    lane: "7",
    series: 1
  },
  {
    athlete: "Samuele Lombardo",
    school: "SSC",
    time: "2:40.69",
    lane: "5",
    series: 2
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "3:28.20",
    lane: "3",
    series: 2
  },
  {
    athlete: "Dario Sanfilippo",
    school: "SSC",
    time: "DNS",
    lane: "4",
    series: 2
  },
  {
    athlete: "Antonino Volante",
    school: "SSC",
    time: "DNS",
    lane: "5",
    series: 2
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: "3:58.00",
    lane: "6",
    series: 1
  },
  {
    athlete: "Bruno d’Arrigo",
    school: "SSC",
    time: "3:48.28",
    lane: "4",
    series: 2
  }
];

export { data };
