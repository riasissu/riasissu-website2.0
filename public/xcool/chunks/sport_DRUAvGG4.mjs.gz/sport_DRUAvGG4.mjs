import './atletica_fp7iYFyS.mjs';

const altoM = new Proxy({"src":"/xcool/_astro/highjump.CqkVAsbo.jpeg","width":275,"height":183,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/highjump.jpeg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/highjump.jpeg");
							return target[name];
						}
					});

const altoF = new Proxy({"src":"/xcool/_astro/highjumpF.BrRtwlhe.jpeg","width":275,"height":183,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/highjumpF.jpeg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/highjumpF.jpeg");
							return target[name];
						}
					});

const lungoM = new Proxy({"src":"/xcool/_astro/longM.BTM_n9Hz.jpeg","width":275,"height":183,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/longM.jpeg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/longM.jpeg");
							return target[name];
						}
					});

const lungoF = new Proxy({"src":"/xcool/_astro/longF.CvHGZARG.jpg","width":2406,"height":1604,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/longF.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/longF.jpg");
							return target[name];
						}
					});

const pesoM = new Proxy({"src":"/xcool/_astro/pesoM.CsWPAp8A.avif","width":440,"height":248,"format":"avif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pesoM.avif";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pesoM.avif");
							return target[name];
						}
					});

const pesoF = new Proxy({"src":"/xcool/_astro/pesoF.-0m5ebZV.jpeg","width":1200,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pesoF.jpeg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pesoF.jpeg");
							return target[name];
						}
					});

const vortex = new Proxy({"src":"/xcool/_astro/vortex.DIJ4mz3R.webp","width":1100,"height":717,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/vortex.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/vortex.webp");
							return target[name];
						}
					});

const corseM = new Proxy({"src":"/xcool/_astro/corseM.CzCLWmd9.avif","width":900,"height":760,"format":"avif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/corseM.avif";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/corseM.avif");
							return target[name];
						}
					});

const corseF = new Proxy({"src":"/xcool/_astro/corseF.hA7dFChO.jpg","width":1200,"height":800,"format":"jpg","orientation":1}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/corseF.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/corseF.jpg");
							return target[name];
						}
					});

const staffettaM = new Proxy({"src":"/xcool/_astro/staffettaM.C7xHEUSH.jpg","width":1800,"height":1020,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaM.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaM.jpg");
							return target[name];
						}
					});

const staffettaF = new Proxy({"src":"/xcool/_astro/staffettaF.Bap_50rD.jpg","width":1080,"height":720,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaF.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaF.jpg");
							return target[name];
						}
					});

const staffetta = new Proxy({"src":"/xcool/_astro/staffetta.EuIMb1a_.jpg","width":800,"height":450,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffetta.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffetta.jpg");
							return target[name];
						}
					});

const cards = [
  {
    href: "/xcool/tabelloni/atletica/alto/altoM",
    imgSrc: altoM.src,
    title: "Salto in Alto Maschile",
    participants: "7 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/alto/altoF",
    imgSrc: altoF.src,
    title: "Salto in Alto Femminile",
    participants: "4 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/lungoM",
    imgSrc: lungoM.src,
    title: "Salto in Lungo Maschile",
    participants: "8 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/lungoF",
    imgSrc: lungoF.src,
    title: "Salto in Lungo Femminile",
    participants: "7 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/pesoM",
    imgSrc: pesoM.src,
    title: "Getto del Peso Maschile",
    participants: "7 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/pesoF",
    imgSrc: pesoF.src,
    title: "Getto del Peso Femminile",
    participants: "4 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/vortexM",
    imgSrc: vortex.src,
    title: "Lancio del Vortex Maschile",
    participants: "13 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/vortexF",
    imgSrc: vortex.src,
    title: "Lancio del Vortex Femminile",
    participants: "3 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/100mF_batterie",
    imgSrc: corseF.src,
    title: "100m Femminile - Batterie",
    participants: "14 partecipanti"
  },
  {
    href: "/xcool/tabelloni/atletica/corse/100mM_batterie",
    imgSrc: corseM.src,
    title: "100m Maschile - Batterie",
    participants: "23 partecipanti"
  },
  {
    href: "/xcool/tabelloni/atletica/corse/4x100mF",
    imgSrc: staffettaF.src,
    title: "4x100m Femminile",
    participants: "6 squadre"
  },
  {
    href: "/xcool/tabelloni/atletica/corse/4x100mM_batterie",
    imgSrc: staffettaM.src,
    title: "4x100m Maschile - Batterie",
    participants: "8 squadre"
  },
  {
    href: "/xcool/tabelloni/atletica/corse/4x400m",
    imgSrc: staffetta.src,
    title: "4x400m Mista",
    participants: "9 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/400mF",
    imgSrc: corseF.src,
    title: "400m Femminile",
    participants: "6 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/400mM",
    imgSrc: corseM.src,
    title: "400m Maschile",
    participants: "15 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/1500mM",
    imgSrc: corseM.src,
    title: "1500m Maschile",
    participants: "20 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/1500mF",
    imgSrc: corseF.src,
    title: "1500m Femminile",
    participants: "8 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/5000mM",
    imgSrc: corseM.src,
    title: "5000m Maschile",
    participants: "24 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/atletica/corse/5000mF",
    imgSrc: corseF.src,
    title: "5000m Femminile",
    participants: "7 partecipanti   "
  }
];

export { cards };
