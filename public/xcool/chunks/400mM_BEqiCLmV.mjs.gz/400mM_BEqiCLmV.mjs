const data = [
  {
    athlete: "Filippo Troina",
    school: "SSC",
    time: "",
    lane: 3,
    series: 2
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: "",
    lane: 2,
    series: 2
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: "",
    lane: 5,
    series: 1
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    time: "",
    lane: 2,
    series: 1
  },
  {
    athlete: "Lorenzo Montano",
    school: "SSC",
    time: "",
    lane: 5,
    series: 3
  },
  {
    athlete: "Giovanni  Marzioni",
    school: "SSSAS",
    time: "",
    lane: 4,
    series: 3
  },
  {
    athlete: "Matteo Leveque",
    school: "SSSAS",
    time: "",
    lane: 1,
    series: 1
  },
  {
    athlete: "Giovanni Gerardo",
    school: "SGSS",
    time: "",
    lane: 6,
    series: 3
  },
  {
    athlete: "Santi  Fisichella",
    school: "SSC",
    time: "",
    lane: 2,
    series: 3
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    lane: 6,
    series: 1
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "",
    lane: 3,
    series: 1
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: "",
    lane: 3,
    series: 3
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: "",
    lane: 6,
    series: 2
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    time: "",
    lane: 4,
    series: 1
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: "",
    lane: 5,
    series: 2
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: "",
    lane: 4,
    series: 2
  }
];

export { data };
