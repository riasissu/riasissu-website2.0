const data1 = [
  {
    athlete: "Francesca M. P. Greco",
    // Maria Piera
    school: "SSC",
    time: ""
  },
  {
    athlete: "Desirè La Manna",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Elena Dichiara",
    school: "SSMC",
    time: ""
  },
  {
    athlete: "Rachele Dentesani",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Alessandra Milone",
    school: "SSC",
    time: ""
  }
];
const data2 = [
  {
    athlete: "Maddalena Feltrin",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Maria Elena Arrigo",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Eleonora Cannella",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Chiara Fantin",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Carla Migliorisi",
    school: "SSC",
    time: ""
  }
];
const data3 = [
  {
    athlete: "Giulia M. Giacchetto",
    //Maria
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Alice Nanni",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Francesca Ciocchi",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Arianna Pedone",
    school: "SSC",
    time: ""
  }
];

export { data1, data2, data3 };
