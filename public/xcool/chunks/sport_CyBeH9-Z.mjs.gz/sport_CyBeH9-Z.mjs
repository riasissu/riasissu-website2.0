const slM = new Proxy({"src":"/xcool/_astro/nuotoM.BeKPL5a6.webp","width":1200,"height":600,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotoM.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotoM.webp");
							return target[name];
						}
					});

const slF = new Proxy({"src":"/xcool/_astro/nuotovF.D-I1z92s.avif","width":1200,"height":630,"format":"avif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotovF.avif";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotovF.avif");
							return target[name];
						}
					});

const doM = new Proxy({"src":"/xcool/_astro/dorsoM.DNIpEPjv.webp","width":1024,"height":682,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/dorsoM.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/dorsoM.webp");
							return target[name];
						}
					});

const raM = new Proxy({"src":"/xcool/_astro/ranaM.DyZX_FtP.webp","width":1200,"height":800,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/ranaM.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/ranaM.webp");
							return target[name];
						}
					});

const doF = new Proxy({"src":"/xcool/_astro/dorsoF.DHYNXG5E.webp","width":1200,"height":800,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/dorsoF.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/dorsoF.webp");
							return target[name];
						}
					});

const raF = new Proxy({"src":"/xcool/_astro/rana.CLRcCd0B.webp","width":1280,"height":720,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/rana.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/rana.webp");
							return target[name];
						}
					});

const staffetta = new Proxy({"src":"/xcool/_astro/staffettaN.DjT6Epcy.webp","width":700,"height":469,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaN.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaN.webp");
							return target[name];
						}
					});

const cards = [
  {
    href: "/xcool/tabelloni/nuoto/sl50M",
    imgSrc: slM.src,
    title: "50m Stile Libero Maschile",
    participants: "11 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/sl50F",
    imgSrc: slF.src,
    title: "50m Stile Libero Femminile",
    participants: "7 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/sl200M",
    imgSrc: slM.src,
    title: "200m Stile Libero Maschile",
    participants: "11 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/do50M",
    imgSrc: doM.src,
    title: "50m Dorso Maschile",
    participants: "5 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/ra50M",
    imgSrc: raM.src,
    title: "50m Rana Maschile",
    participants: "8 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/sl4x50",
    imgSrc: staffetta.src,
    title: "Staffetta 4x50m Stile Libero",
    participants: "4 partecipanti"
  },
  {
    href: "/xcool/tabelloni/nuoto/sl200F",
    imgSrc: slF.src,
    title: "200m Stile Libero Femminile",
    participants: "5 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/do50F",
    imgSrc: doF.src,
    title: "50m Dorso Femminile",
    participants: "5 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/ra50F",
    imgSrc: raF.src,
    title: "50m Rana Femminile",
    participants: "5 partecipanti   "
  }
];

export { cards };
