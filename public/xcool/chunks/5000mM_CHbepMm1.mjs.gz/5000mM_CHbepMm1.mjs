const data = [
  {
    athlete: "Riccardo Vigneri",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Tommaso Ulian",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Leonardo Rossi",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Federico Rinelli",
    school: "ISUFI",
    time: ""
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Giuseppe Monaco",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Lorenzo Lo Cascio",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Michele Gomba",
    school: "SSST",
    time: ""
  },
  {
    athlete: "Emilio Ferrante",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Piersanti Di Stefano",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Stefano Di Iulio",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Davide Cicchetti",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Leonardo Alma",
    school: "SSC",
    time: ""
  }
];

export { data };
