const data = [
  {
    athlete: "Giacomo Bortolussi",
    school: "SSDTW",
    time: "",
    lane: "2A"
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    lane: "3A"
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "",
    lane: "4A"
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: "",
    lane: "5A"
  },
  {
    athlete: "Nicolò Brunacci",
    school: "SSST",
    time: "",
    lane: "6A"
  },
  {
    athlete: "Samuele Lombardo",
    school: "SSC",
    time: "",
    lane: "2B"
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "",
    lane: "3B"
  },
  {
    athlete: "Dario Sanfilippo",
    school: "SSC",
    time: "",
    lane: "4B"
  },
  {
    athlete: "Antonino Volante",
    school: "SSC",
    time: "",
    lane: "5B"
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: "",
    lane: "6B"
  },
  {
    athlete: "Bruno d’Arrigo",
    school: "SSC",
    time: "",
    lane: "7B"
  }
];

export { data };
