const data = [
  {
    athlete: "Federico Rinelli",
    school: "ISUFI",
    time: ""
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Giuseppe Monaco",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Giovanni  Marzioni ",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Matteo Leveque",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Michele Gomba",
    school: "SSST",
    time: ""
  },
  {
    athlete: "Giovanni Gerardo",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Santi  Fisichella",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Emilio Ferrante",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: ""
  },
  {
    athlete: "Stefano Di Iulio",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: ""
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: ""
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Davide Cicchetti",
    school: "SSSAS",
    time: ""
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: ""
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: ""
  }
];

export { data };
