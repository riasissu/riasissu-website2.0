const slM = new Proxy({"src":"/xcool/_astro/nuotoM.DSnVxVf0.jpg","width":1200,"height":600,"format":"jpg","orientation":1}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotoM.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotoM.jpg");
							return target[name];
						}
					});

const slF = new Proxy({"src":"/xcool/_astro/nuotovF.D-I1z92s.avif","width":1200,"height":630,"format":"avif"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotovF.avif";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/nuotovF.avif");
							return target[name];
						}
					});

const doM = new Proxy({"src":"/xcool/_astro/dorsoM.CqI2lCZ9.jpg","width":1024,"height":682,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/dorsoM.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/dorsoM.jpg");
							return target[name];
						}
					});

const raM = new Proxy({"src":"/xcool/_astro/ranaM.CAmRwRmG.jpg","width":1200,"height":800,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/ranaM.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/ranaM.jpg");
							return target[name];
						}
					});

const staffetta = new Proxy({"src":"/xcool/_astro/staffettaN.thj_Bom0.jpg","width":700,"height":469,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaN.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/staffettaN.jpg");
							return target[name];
						}
					});

const cards = [
  {
    href: "/xcool/tabelloni/nuoto/sl50M",
    imgSrc: slM.src,
    title: "50m Stile Libero Maschile",
    participants: "11 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/sl50F",
    imgSrc: slF.src,
    title: "50m Stile Libero Femminile",
    participants: "7 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/sl200M",
    imgSrc: slM.src,
    title: "200m Stile Libero Maschile",
    participants: "11 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/do50M",
    imgSrc: doM.src,
    title: "50m Dorso Maschile",
    participants: "5 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/ra50M",
    imgSrc: raM.src,
    title: "50m Rana Maschile",
    participants: "8 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/sl4x50",
    imgSrc: staffetta.src,
    title: "Staffetta 4x50m Stile Libero",
    participants: "4 partecipanti"
  },
  {
    href: "/xcool/tabelloni/nuoto/sl200F",
    imgSrc: slM.src,
    title: "200m Stile Libero Femminile",
    participants: "5 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/do50F",
    imgSrc: doM.src,
    title: "50m Dorso Femminile",
    participants: "5 partecipanti   "
  },
  {
    href: "/xcool/tabelloni/nuoto/ra50F",
    imgSrc: raM.src,
    title: "50m Rana Femminile",
    participants: "5 partecipanti   "
  }
];

export { cards };
