const data = [
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    attempts: ["47.20", "48.09"]
  },
  {
    athlete: "Vittorio Magnaguagno",
    school: "SGSS",
    attempts: ["30.94", "30.94"]
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    attempts: ["47.47", "49.60"]
  },
  {
    athlete: "Francesco Decataldo",
    school: "SSDTW",
    attempts: ["50.31", "50.31"]
  },
  {
    athlete: "Leonardo Danelutti",
    school: "SSDTW",
    attempts: ["53.09", "64.75"]
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    attempts: ["62.37", "62.37"]
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    attempts: ["26.10"]
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    attempts: ["53.85", "54.05"]
  },
  {
    athlete: "Lorenzo Weiss",
    school: "SGSS",
    attempts: ["41.88", "41.88"]
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    attempts: ["20.83"]
  },
  {
    athlete: "Giovanni Gerardo",
    school: "SGSS",
    attempts: ["22.64"]
  }
];

export { data };
