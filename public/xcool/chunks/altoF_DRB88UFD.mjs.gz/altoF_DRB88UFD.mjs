const heights = [
  0.9,
  1,
  1.1,
  1.15,
  1.2,
  1.23,
  1.26,
  1.29,
  1.32
];
const data = [
  {
    athlete: "Chiara Fantin",
    school: "SGSS",
    note: "",
    attempts: {
      "0.90": "-",
      "1.00": "O",
      "1.10": "O",
      "1.15": "XXX"
    }
  },
  {
    athlete: "Ilaria Bruno",
    school: "SSDTW",
    note: "",
    attempts: {
      "0.90": "O",
      "1.00": "O",
      "1.10": "XXX"
    }
  },
  {
    athlete: "Francesca Ciocchi",
    school: "SGSS",
    note: "",
    attempts: {
      "0.90": "-",
      "1.00": "-",
      "1.10": "O",
      "1.15": "O",
      "1.20": "XO",
      "1.23": "XXX"
    }
  },
  {
    athlete: "Lara Guglielmucci",
    school: "SSSAS",
    note: "",
    attempts: {
      "0.90": "-",
      "1.00": "O",
      "1.10": "XXX"
    }
  },
  {
    athlete: "Chiara Mascitelli",
    school: "SGSS",
    note: "",
    attempts: {
      "0.90": "-",
      "1.00": "O",
      "1.10": "O",
      "1.15": "O",
      "1.20": "O",
      "1.23": "XXX"
    }
  },
  {
    athlete: "Francesca Busato",
    school: "SSDTW",
    note: "",
    attempts: {
      "0.90": "O",
      "1.00": "O",
      "1.10": "XO",
      "1.15": "XXX"
    }
  }
];

export { data, heights };
