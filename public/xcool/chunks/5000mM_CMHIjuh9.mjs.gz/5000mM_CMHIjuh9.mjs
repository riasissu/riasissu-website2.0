const data = [
  {
    athlete: "Riccardo Vigneri",
    school: "SSC",
    time: "20:26.00",
    series: 2
  },
  {
    athlete: "Tommaso Ulian",
    school: "SSDTW",
    time: "DNS",
    series: 1
  },
  {
    athlete: "Leonardo Rossi",
    school: "SSDTW",
    time: "23:13.00",
    series: 2
  },
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: "DNS",
    series: 1
  },
  {
    athlete: "Federico Rinelli",
    school: "ISUFI",
    time: "21:27.00",
    series: 1
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: "DNS",
    series: 1
  },
  {
    athlete: "Giuseppe Monaco",
    school: "SSC",
    time: "DNS",
    series: 2
  },
  {
    athlete: "Simone Milesi",
    school: "SSDTW",
    time: "21:35.00",
    series: 1
  },
  {
    athlete: "Pietro Marinoni",
    school: "SGSS",
    time: "22:01.00",
    series: 2
  },
  {
    athlete: "Lorenzo Lo Cascio",
    school: "CSB",
    time: "21:31.00",
    series: 2
  },
  {
    athlete: "Michele Gomba",
    school: "SSST",
    time: "21:43.00",
    series: 2
  },
  {
    athlete: "Emilio Ferrante",
    school: "SSSAS",
    time: "DNS",
    series: 2
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: "DNS",
    series: 1
  },
  {
    athlete: "Piersanti Di Stefano",
    school: "SSC",
    time: "21:50.00",
    series: 2
  },
  {
    athlete: "Stefano Di Iulio",
    school: "SGSS",
    time: "20:12.50",
    series: 2
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "27.08.00",
    series: 1
  },
  {
    athlete: "Simone De Angelis",
    school: "CSB",
    time: "24:20.00",
    series: 2
  },
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "17:52.00",
    series: 1
  },
  {
    athlete: "Marco Civello",
    school: "SSC",
    time: "DNF",
    series: 1
  },
  {
    athlete: "Fabio Cimino",
    school: "SGSS",
    time: "18:07.00",
    series: 2
  },
  {
    athlete: "Davide Cicchetti",
    school: "SSSAS",
    time: "20:41.00",
    series: 2
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: "18:09.49",
    series: 1
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: "17:13.00",
    series: 1
  },
  {
    athlete: "Leonardo Alma",
    school: "SSC",
    time: "DNS",
    series: 2
  },
  {
    athlete: "Samuele L. Marino",
    //Libero
    school: "SGSS",
    time: "DNS",
    series: 1
  }
];

export { data };
