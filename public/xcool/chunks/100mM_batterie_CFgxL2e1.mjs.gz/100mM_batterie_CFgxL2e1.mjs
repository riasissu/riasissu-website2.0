const data1 = [
  /* {
     athlete: "Francesco Peroni",
     school: "SGSS",
     lane: 5,
     time: "10.05",
     qualifier: "Q"
  }, */
  {
    athlete: "Giovanni Marzioni",
    school: "SSSAS",
    time: "",
    lane: 1
  },
  {
    athlete: "Santi Fisichella",
    school: "SSC",
    time: "",
    lane: 2
  },
  {
    athlete: "Lorenzo Murace",
    school: "CSB",
    time: "",
    lane: 3
  },
  {
    athlete: "Federico Bais",
    school: "SSDTW",
    time: "",
    lane: 4
  },
  {
    athlete: "Simone Fisichella",
    school: "SGSS",
    time: "",
    lane: 5
  },
  {
    athlete: "Andrea Benini",
    school: "SSST",
    time: "",
    lane: 6
  }
];
const data2 = [
  {
    athlete: "Nicolas Rodigari",
    school: "CSB",
    time: "",
    lane: 2
  },
  {
    athlete: "Gabriele B. Finocchiaro",
    //Bartolomeo
    school: "SSC",
    time: "",
    lane: 3
  },
  {
    athlete: "Flavio Falcone",
    school: "SSC",
    time: "",
    lane: 4
  },
  {
    athlete: "Nazareno Piccin",
    school: "SSDTW",
    time: "",
    lane: 5
  },
  {
    athlete: "Giulio De Musso",
    school: "ISUFI",
    time: "",
    lane: 6
  }
];
const data3 = [
  {
    athlete: "Lorenzo Montano",
    school: "SSC",
    time: "",
    lane: 2
  },
  {
    athlete: "Tommaso Malpensa",
    school: "CSB",
    time: "",
    lane: 3
  },
  {
    athlete: "Gioele Clemente",
    school: "SSDTW",
    time: "",
    lane: 4
  },
  {
    athlete: "Gabriele De Marco",
    school: "CSB",
    time: "",
    lane: 5
  }
];
const data4 = [
  {
    athlete: "Mattia Clemente",
    school: "SSDTW",
    time: "",
    lane: 2
  },
  {
    athlete: "Lorenzo Cattani",
    school: "SGSS",
    time: "",
    lane: 3
  },
  {
    athlete: "Filippo Troina",
    school: "SSC",
    time: "",
    lane: 4
  },
  {
    athlete: "Elia Pilati",
    school: "CSB",
    time: "",
    lane: 5
  },
  {
    athlete: "Francesco Decataldo",
    school: "SSDTW",
    time: "",
    lane: 6
  }
];

export { data1, data2, data3, data4 };
