const data1 = [
  {
    athlete: "Desirè La Manna",
    school: "SSC",
    time: "19.56",
    lane: 2
  },
  {
    athlete: "Francesca M. P. Greco",
    // Maria Piera
    school: "SSC",
    time: "18.75",
    lane: 3
  },
  {
    athlete: "Elena Dichiara",
    school: "SSMC",
    time: "15.63",
    lane: 4,
    qualifier: "Q"
  },
  {
    athlete: "Rachele Dentesani",
    school: "SSDTW",
    time: "16.00",
    lane: 5,
    qualifier: "q"
  },
  {
    athlete: "Ludovica Giannino",
    school: "SSC",
    time: "20.38",
    lane: 6
  }
];
const data2 = [
  {
    athlete: "Maddalena Feltrin",
    school: "SSDTW",
    time: "16.88",
    lane: 2
  },
  {
    athlete: "Maria Elena Arrigo",
    school: "SSC",
    time: "15.88",
    lane: 3,
    qualifier: "Q"
  },
  {
    athlete: "Eleonora Cannella",
    school: "SSC",
    time: "DNS",
    lane: 4
  },
  {
    athlete: "Chiara Fantin",
    school: "SGSS",
    time: "15.97",
    lane: 5,
    qualifier: "q"
  },
  {
    athlete: "Carla Migliorisi",
    school: "SSC",
    time: "17.60",
    lane: 6
  }
];
const data3 = [
  {
    athlete: "Noemi Ercoli",
    school: "SSMC",
    time: "20.78",
    lane: 2
  },
  {
    athlete: "Alice Nanni",
    school: "SSSAS",
    time: "17.52",
    lane: 3,
    qualifier: "q"
  },
  {
    athlete: "Francesca Ciocchi",
    school: "SGSS",
    time: "14.90",
    lane: 4,
    qualifier: "Q"
  },
  {
    athlete: "Arianna Pedone",
    school: "SSC",
    time: "16.69",
    lane: 5
  },
  {
    athlete: "Serena Poloni",
    school: "SSMC",
    time: "20.54",
    lane: 5
  }
];

export { data1, data2, data3 };
