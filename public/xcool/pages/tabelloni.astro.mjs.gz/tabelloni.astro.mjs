import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../chunks/astro/server_BE-4ZxlD.mjs';
import 'kleur/colors';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery, $ as $$Layout } from '../chunks/Layout_Abjf1cfq.mjs';
import { F as FadeIn } from '../chunks/FadeIn_PMWA91fe.mjs';
export { renderers } from '../renderers.mjs';

const medals = new Proxy({"src":"/xcool/_astro/medals.UJ-vpkB_.webp","width":3438,"height":1209,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/medals.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/medals.webp");
							return target[name];
						}
					});

const tennis = new Proxy({"src":"/xcool/_astro/tennis.DIaUFq7G.webp","width":1280,"height":720,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/tennis.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/tennis.webp");
							return target[name];
						}
					});

const chess = new Proxy({"src":"/xcool/_astro/chess.hO3H6no6.webp","width":400,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/chess.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/chess.webp");
							return target[name];
						}
					});

const pingpong = new Proxy({"src":"/xcool/_astro/pingpong.D_QnpbGZ.webp","width":449,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pingpong.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pingpong.webp");
							return target[name];
						}
					});

const padel = new Proxy({"src":"/xcool/_astro/padel.BLzSu1XT.webp","width":749,"height":500,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/padel.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/padel.webp");
							return target[name];
						}
					});

const volley = new Proxy({"src":"/xcool/_astro/pallavolo.CrmPCldw.webp","width":922,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pallavolo.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pallavolo.webp");
							return target[name];
						}
					});

const calcio = new Proxy({"src":"/xcool/_astro/calcio.IuwuZTP8.webp","width":450,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/calcio.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/calcio.webp");
							return target[name];
						}
					});

const beachvolley = new Proxy({"src":"/xcool/_astro/beachvolley.0hk5WDF0.webp","width":400,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/beachvolley.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/beachvolley.webp");
							return target[name];
						}
					});

const biliardino = new Proxy({"src":"/xcool/_astro/biliardino.DqaF_tno.webp","width":400,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/biliardino.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/biliardino.webp");
							return target[name];
						}
					});

const dibattito = new Proxy({"src":"/xcool/_astro/Debate.CsX0WeEx.webp","width":475,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/Debate.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/Debate.webp");
							return target[name];
						}
					});

const basket = new Proxy({"src":"/xcool/_astro/basket.CmHphmvV.webp","width":2462,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/basket.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/basket.webp");
							return target[name];
						}
					});

const atletica = new Proxy({"src":"/xcool/_astro/atletica.C23vrCCi.webp","width":720,"height":400,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/atletica.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/atletica.webp");
							return target[name];
						}
					});

const swim = new Proxy({"src":"/xcool/_astro/swim.CdPNIL_I.webp","width":720,"height":480,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/swim.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/swim.webp");
							return target[name];
						}
					});

const justdance = new Proxy({"src":"/xcool/_astro/justdance.B6BHDzyb.webp","width":299,"height":168,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/justdance.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/justdance.webp");
							return target[name];
						}
					});

const mariokart = new Proxy({"src":"/xcool/_astro/mariokart.YrdBK1qS.webp","width":1024,"height":587,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/mariokart.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/mariokart.webp");
							return target[name];
						}
					});

const marioparty = new Proxy({"src":"/xcool/_astro/marioparty.BPJbhXpY.webp","width":1600,"height":800,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/marioparty.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/marioparty.webp");
							return target[name];
						}
					});

const briscola = new Proxy({"src":"/xcool/_astro/briscola.BQKL5LjD.webp","width":1280,"height":720,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/briscola.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/briscola.webp");
							return target[name];
						}
					});

const admo = new Proxy({"src":"/xcool/_astro/admo.Dg-vRq-x.webp","width":1081,"height":647,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/admo.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/admo.webp");
							return target[name];
						}
					});

const pokemon = new Proxy({"src":"/xcool/_astro/pokemon.C6l62zTj.jpg","width":2000,"height":1000,"format":"jpg"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pokemon.jpg";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/pokemon.jpg");
							return target[name];
						}
					});

const cards = [
  {
    href: "/xcool/tabelloni/atletica",
    imgSrc: atletica.src,
    title: "Atletica",
    description: "19 competizioni."
  },
  {
    href: "/xcool/tabelloni/nuoto",
    imgSrc: swim.src,
    title: "Nuoto",
    description: "6 competizioni."
  },
  {
    href: "/xcool/tabelloni/xcool_tennis",
    imgSrc: tennis.src,
    title: "Tennis",
    format: "Torneo a eliminazione diretta.",
    participants: "8 squadre"
  },
  {
    href: "/xcool/tabelloni/xcool_quadriglia",
    imgSrc: chess.src,
    title: "Scacchi - Quadriglia",
    format: "Torneo svizzero a 6 round.",
    participants: "7 squadre"
  },
  {
    href: "/xcool/tabelloni/xcool_scacchi_blitz",
    imgSrc: chess.src,
    title: "Scacchi - Rapid",
    format: "Torneo svizzero a 6 round.",
    participants: "TBD"
  },
  {
    href: "/xcool/tabelloni/xcool_scacchi_rapid",
    imgSrc: chess.src,
    title: "Scacchi - Blitz",
    format: "Torneo svizzero a 6 round.",
    participants: "TBD"
  },
  {
    href: "/xcool/tabelloni/xcool_scacchi_classic",
    imgSrc: chess.src,
    title: "Scacchi - Classic",
    format: "Torneo svizzero.",
    participants: "TBD"
  },
  {
    href: "/xcool/tabelloni/xcool_pingpong",
    imgSrc: pingpong.src,
    title: "Tennis Tavolo",
    format: "Gironi (6 -> 1), poi eliminazione diretta.",
    participants: "48 giocatori."
  },
  {
    href: "/xcool/tabelloni/xcool_padel",
    imgSrc: padel.src,
    title: "Padel",
    format: "Torneo a eliminazione diretta.",
    participants: "19 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_pallavolo",
    imgSrc: volley.src,
    title: "Pallavolo",
    format: "Gironi (4 -> 2), poi eliminazione diretta.",
    participants: "13 squadre."
  },
  // {
  //   href: "/xcool/tabelloni/coppa_chiosco",
  //   imgSrc: chiosco.src,
  //   title: "Coppa Chiosco",
  //   format: "Bevi più che puoi!",
  //   participants: "11 scuole.",
  // },
  {
    href: "/xcool/tabelloni/xcool_calcio_maschile",
    imgSrc: calcio.src,
    title: "Calcio a 5 Maschile",
    format: "Gironi (5 -> 4), poi eliminazione diretta.",
    participants: "10 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_calcio_femminile",
    imgSrc: calcio.src,
    title: "Calcio a 5 Femminile",
    format: "Gironi (3 -> 2), poi eliminazione diretta.",
    participants: "3 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_beachvolley",
    imgSrc: beachvolley.src,
    title: "Beach Volley",
    format: "Gironi (3 -> 1), poi eliminazione diretta.",
    participants: "36 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_basket",
    imgSrc: basket.src,
    title: "Basket",
    format: "Gironi (3 -> 2), poi eliminazione diretta.",
    participants: "6 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_dibattito",
    imgSrc: dibattito.src,
    title: "Dibattito Competitivo",
    format: "Torneo all'italiana.",
    participants: "3 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_biliardino",
    imgSrc: biliardino.src,
    title: "Biliardino",
    format: "Gironi (4->1), poi eliminazione diretta.",
    participants: "48 squadre."
  },
  {
    href: "/xcool/tabelloni/xcool_justdance",
    imgSrc: justdance.src,
    title: "Just Dance",
    format: "Free for All, 6 persone a round.",
    participants: "48 partecipanti."
  },
  {
    href: "/xcool/tabelloni/xcool_mariokart",
    imgSrc: mariokart.src,
    title: "Mario Kart",
    format: "Free for all, round da 4 persone.",
    participants: "48 partecipanti"
  },
  {
    href: "/xcool/tabelloni/xcool_marioparty",
    imgSrc: marioparty.src,
    title: "Mario Party",
    format: "Free for all, round da 4 persone.",
    participants: "20 partecipanti"
  },
  {
    href: "/xcool/tabelloni/xcool_briscola",
    imgSrc: briscola.src,
    title: "Briscola",
    format: "Gironi all'italiana (5/6 -> 1), poi eliminazione diretta.",
    participants: "53 partecipanti."
  },
  {
    href: "/xcool/tabelloni/coppa_admo",
    imgSrc: admo.src,
    title: "Coppa ADMO",
    format: "Regolamento sul sito RIASISSU.",
    participants: "11 scuole."
  },
  {
    href: "/xcool/tabelloni/xcool_pokemon12",
    imgSrc: pokemon.src,
    title: "Pokémon VGC12",
    format: "",
    participants: "12 partecipanti."
  },
  {
    href: "/xcool/tabelloni/xcool_pokemon25",
    imgSrc: pokemon.src,
    title: "Pokémon VGC25",
    format: "",
    participants: "12 partecipanti."
  }
  // ...add as many as you like
];

const medalTable = {
  href: "/xcool/tabelloni/medals",
  imgSrc: medals.src,
  title: "Medagliere"};
const PageWrapper = styled.div`
  padding: 40px;
  background: ${Theme.secondary};
`;
const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 24px;

  ${MediaQuery.max("md")} {
    grid-template-columns: 1fr;
  }
`;
const CardLink = styled.a`
  display: block;
  text-decoration: none;
  color: inherit;
  border-radius: 12px;
  overflow: hidden;
  max-width: 875px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  transition:
    transform 0.3s,
    box-shadow 0.3s;
  border-color: #94a3b87d;
  border-style: solid;
  border-width: 0.5px;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.15);
  }
`;
const CardImage = styled.img`
  width: 100%;
  height: 160px;
  object-fit: cover;
`;
const CardContent = styled.div`
  padding: 16px;
  background: ${Theme.secondary};
`;
const CardTitle = styled.h3`
  margin: 0 0 8px;
  font-size: 20px;
  line-height: 1.2;
  color: ${Theme.primary};
`;
const CardDescription = styled.div`
  margin: 2px;
  font-size: 14px;
  color: #cbcacd;
`;
const MedalDiv = styled.div`
  margin-bottom: 48px;
  max-width: 810px;
  margin-left: auto;
  margin-right: auto;
`;
const CardGallery = () => /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsxs(PageWrapper, { children: [
  /* @__PURE__ */ jsx(MedalDiv, { children: /* @__PURE__ */ jsxs(CardLink, { href: medalTable.href, children: [
    /* @__PURE__ */ jsx(
      CardImage,
      {
        src: medalTable.imgSrc,
        alt: medalTable.title,
        fetchPriority: "high"
      }
    ),
    /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsx(CardTitle, { children: medalTable.title }) })
  ] }, medalTable.href) }),
  /* @__PURE__ */ jsx(Grid, { children: cards.map((c) => {
    const priority = c.title == "Atletica" ? "high" : "auto";
    return /* @__PURE__ */ jsxs(CardLink, { href: c.href, children: [
      /* @__PURE__ */ jsx(
        CardImage,
        {
          src: c.imgSrc,
          alt: c.title,
          fetchPriority: priority
        }
      ),
      /* @__PURE__ */ jsxs(CardContent, { children: [
        /* @__PURE__ */ jsx(CardTitle, { children: c.title }),
        c.format && /* @__PURE__ */ jsxs(CardDescription, { children: [
          /* @__PURE__ */ jsx("strong", { children: "Formato: " }),
          c.format
        ] }),
        c.participants && /* @__PURE__ */ jsxs(CardDescription, { children: [
          /* @__PURE__ */ jsx("strong", { children: "Partecipanti: " }),
          c.participants
        ] }),
        c.description && /* @__PURE__ */ jsxs(CardDescription, { children: [
          /* @__PURE__ */ jsx("strong", { children: "Descrizione: " }),
          c.description
        ] })
      ] })
    ] }, c.href);
  }) })
] }) });

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center> <h1 class="page-title" style="margin-top: 200px;">
Gironi e Tabelloni
</h1> <div style="color:#94A3B8; padding: 40px">
Sport presenti alle XCool con relativo tabellone. <a class="link" href="/xcool/info">Clicca qui</a> per vedere calendario, programma ed altre informazioni!
</div> </center> <div style="overflow:auto;"> ${renderComponent($$result2, "CardGallery", CardGallery, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@components/Card/CardGallery", "client:component-export": "default" })} </div> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/index.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/index.astro";
const $$url = "/xcool/tabelloni";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Index,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
