import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_BE-4ZxlD.mjs';
import 'kleur/colors';
import { jsx, jsxs } from 'react/jsx-runtime';
import React, { useState } from 'react';
import styled from '@emotion/styled';
import { T as Theme, $ as $$Layout } from '../../chunks/Layout_Abjf1cfq.mjs';
export { renderers } from '../../renderers.mjs';

const down = new Proxy({"src":"/xcool/_astro/down.ZYNO2wrg.png","width":574,"height":303,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/down.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/down.png");
							return target[name];
						}
					});

const next = new Proxy({"src":"/xcool/_astro/next.Dxpry1eZ.png","width":473,"height":307,"format":"png"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/next.png";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/icons/next.png");
							return target[name];
						}
					});

const TableWrapper = styled.div`
  overflow-x: auto;
  overflow-y: auto;
  margin: 40px 0;
  align-self: center;
`;
const Table = styled.table`
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  font-family: sans-serif;
  background: ${Theme.secondary};
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
  border-radius: 12px;
`;
const Th = styled.th`
  padding: 16px;
  font-weight: 600;
  text-transform: uppercase;
  text-align: center;
  background: ${Theme.secondary};
  color: ${Theme.primary};
  &:first-of-type {
    border-top-left-radius: 12px;
  }
  &:last-of-type {
    border-top-right-radius: 12px;
  }
`;
const BodyRow = styled.tr`
  cursor: pointer;
  &:nth-of-type(odd) {
    background: #626262;
  }
`;
const Cell = styled.td`
  padding: 12px 16px;
  vertical-align: middle;
  text-align: center;
`;
styled.img`
  width: 32px;
  height: 20px;
  object-fit: cover;
  border-radius: 2px;
  margin-right: 8px;
`;
const SchoolCell = styled(Cell)`
  /*display: flex;*/
  align-items: center;
  width: 300px;
`;
const MedalCount = styled.span`
  font-weight: 600;
  color: ${({ color }) => color};
  min-width: 32px;
  display: inline-block;
  text-align: center;
`;
const DetailRow = styled.tr`
  background: ${Theme.primary}CC;
  font-size: 12px;
  color: #b6b6b6;
  &:nth-of-type(odd) {
    background: #474747;
  }
`;
function MedalTable({ data }) {
  const [expandedSchool, setExpandedSchool] = useState(null);
  const sorted = [...data].sort((a, b) => {
    const agold = a.details.reduce((acc, curr) => acc + curr.gold, 0);
    const asilver = a.details.reduce((acc, curr) => acc + curr.silver, 0);
    const abronze = a.details.reduce((acc, curr) => acc + curr.bronze, 0);
    const bgold = b.details.reduce((acc, curr) => acc + curr.gold, 0);
    const bsilver = b.details.reduce((acc, curr) => acc + curr.silver, 0);
    const bbronze = b.details.reduce((acc, curr) => acc + curr.bronze, 0);
    if (bgold !== agold) return bgold - agold;
    if (bsilver !== asilver) return bsilver - asilver;
    return bbronze - abronze;
  });
  const toggle = (school) => setExpandedSchool((cur) => cur === school ? null : school);
  return /* @__PURE__ */ jsx(TableWrapper, { children: /* @__PURE__ */ jsxs(Table, { children: [
    /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
      /* @__PURE__ */ jsx(Th, { children: "#" }),
      /* @__PURE__ */ jsx(Th, { children: "Scuola" }),
      /* @__PURE__ */ jsx(Th, { children: "🥇" }),
      /* @__PURE__ */ jsx(Th, { children: "🥈" }),
      /* @__PURE__ */ jsx(Th, { children: "🥉" }),
      /* @__PURE__ */ jsx(Th, { children: "Totale" })
    ] }) }),
    /* @__PURE__ */ jsx("tbody", { children: sorted.map((c, i) => {
      const cgold = Math.round(100 * c.details.reduce((acc, curr) => acc + curr.gold, 0)) / 100;
      const csilver = Math.round(100 * c.details.reduce((acc, curr) => acc + curr.silver, 0)) / 100;
      const cbronze = Math.round(100 * c.details.reduce((acc, curr) => acc + curr.bronze, 0)) / 100;
      const total = Math.round(100 * (cgold + csilver + cbronze)) / 100;
      const isOpen = expandedSchool === c.school;
      return /* @__PURE__ */ jsxs(React.Fragment, { children: [
        /* @__PURE__ */ jsxs(BodyRow, { onClick: () => toggle(c.school), children: [
          /* @__PURE__ */ jsx(Cell, { children: i + 1 }),
          /* @__PURE__ */ jsxs(SchoolCell, { children: [
            c.school,
            isOpen && /* @__PURE__ */ jsx("img", { width: "20px", src: down.src }),
            !isOpen && /* @__PURE__ */ jsx("img", { width: "15px", src: next.src })
          ] }),
          /* @__PURE__ */ jsx(Cell, { children: /* @__PURE__ */ jsx(MedalCount, { color: "#FFD700", children: cgold }) }),
          /* @__PURE__ */ jsx(Cell, { children: /* @__PURE__ */ jsx(MedalCount, { color: "#C0C0C0", children: csilver }) }),
          /* @__PURE__ */ jsx(Cell, { children: /* @__PURE__ */ jsx(MedalCount, { color: "#CD7F32", children: cbronze }) }),
          /* @__PURE__ */ jsx(SchoolCell, { children: total })
        ] }),
        isOpen && c.details.map((d) => {
          const subTotal = Math.round(100 * (d.gold + d.silver + d.bronze)) / 100;
          const notEmpty = subTotal !== 0;
          return notEmpty && /* @__PURE__ */ jsxs(DetailRow, { children: [
            /* @__PURE__ */ jsx(Cell, {}),
            /* @__PURE__ */ jsx(SchoolCell, { children: d.sport }),
            /* @__PURE__ */ jsx(Cell, { children: d.gold }),
            /* @__PURE__ */ jsx(Cell, { children: d.silver }),
            /* @__PURE__ */ jsx(Cell, { children: d.bronze }),
            /* @__PURE__ */ jsx(SchoolCell, { children: subTotal })
          ] }, d.sport);
        })
      ] }, c.school);
    }) })
  ] }) });
}

const medalData = [
  {
    school: "SSC",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 1 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0.55 },
      { sport: "Tennis", gold: 1, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 2 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 1, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 0, bronze: 0 },
      { sport: "Nuoto", gold: 3, silver: 2, bronze: 2 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 1, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 1 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "CSB",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 1, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 1 },
      { sport: "Atletica", gold: 1, silver: 2, bronze: 3.75 },
      { sport: "Nuoto", gold: 1, silver: 0.5, bronze: 3 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "SSA",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0.25, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 0, bronze: 0 },
      { sport: "Nuoto", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "IUSS",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0.66, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0.22 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 1 },
      { sport: "Padel", gold: 1, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0.25, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 0, bronze: 0 },
      { sport: "Nuoto", gold: 1, silver: 1, bronze: 0 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 1 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "ISUFI",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0.11 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 0, bronze: 0 },
      { sport: "Nuoto", gold: 1.25, silver: 2, bronze: 0 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "SSSAS",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 1 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0.11 },
      { sport: "Tennis", gold: 0, silver: 1, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 1, bronze: 3 },
      { sport: "Nuoto", gold: 0, silver: 0, bronze: 1 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 1, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 1, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 },
      { sport: "Coppa Chiosco", gold: 1, silver: 0, bronze: 0 }
    ]
  },
  {
    school: "SGSS",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 2, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 1 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 1 },
      { sport: "Pallacanestro", gold: 1, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 1, silver: 1, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 1, bronze: 0 },
      { sport: "Atletica", gold: 2, silver: 7, bronze: 5 },
      { sport: "Nuoto", gold: 2.75, silver: 2, bronze: 0 },
      { sport: "Tennis Tavolo", gold: 1, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 2, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 1 },
      { sport: "Mario Kart", gold: 1, silver: 1, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 },
      { sport: "Coppa ADMO", gold: 1, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "SSDTW",
    details: [
      { sport: "Calcio a 5", gold: 2, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 1, silver: 0.17, bronze: 0 },
      { sport: "Beach Volley", gold: 1, silver: 1, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 1, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0.25, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 16, silver: 8, bronze: 6.25 },
      { sport: "Nuoto", gold: 0, silver: 0.25, bronze: 1 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 1, silver: 1, bronze: 2 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 2, silver: 1, bronze: 2 },
      { sport: "Just Dance", gold: 1, silver: 1, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "SSST",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 1 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 0, bronze: 1 },
      { sport: "Nuoto", gold: 0, silver: 1, bronze: 0 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 1 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 1 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "SSMC",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 3, bronze: 0 },
      { sport: "Nuoto", gold: 0, silver: 0, bronze: 1 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 1, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  },
  {
    school: "SSUC",
    details: [
      { sport: "Calcio a 5", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallavolo", gold: 0, silver: 0.17, bronze: 0 },
      { sport: "Beach Volley", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pallacanestro", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis", gold: 0, silver: 0, bronze: 0 },
      { sport: "Padel", gold: 0, silver: 0, bronze: 0 },
      { sport: "Calcetto Balilla", gold: 0, silver: 0, bronze: 0 },
      { sport: "Dibattito Competitivo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Briscola", gold: 0, silver: 0, bronze: 0 },
      { sport: "Atletica", gold: 0, silver: 0, bronze: 0 },
      { sport: "Nuoto", gold: 0, silver: 0, bronze: 0 },
      { sport: "Tennis Tavolo", gold: 0, silver: 0, bronze: 0 },
      { sport: "Scacchi", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Party DS", gold: 0, silver: 0, bronze: 0 },
      { sport: "Mario Kart", gold: 0, silver: 0, bronze: 0 },
      { sport: "Pokémon", gold: 0, silver: 0, bronze: 0 },
      { sport: "Just Dance", gold: 0, silver: 0, bronze: 0 }
      //{ sport: "Coppa Chiosco", gold: 0, silver: 0, bronze: 0 },
    ]
  }
];

const $$Medals = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025 - Medals", "description": "Medal standings for the XCOOL 2025 event." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:200px;">Medagliere</h1> <!-- hydrate on load for interactivity --> <div style="margin: 0 10px 0 10px;max-width: 960px;overflow:auto"> ${renderComponent($$result2, "MedalTable", MedalTable, { "client:load": true, "data": medalData, "client:component-hydration": "load", "client:component-path": "/home/runner/work/xcool-webpage/xcool-webpage/src/components/MedalTable/MedalTable", "client:component-export": "default" })} </div> </center> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/medals.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/medals.astro";
const $$url = "/xcool/tabelloni/medals";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: $$Medals,
	file: $$file,
	url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
