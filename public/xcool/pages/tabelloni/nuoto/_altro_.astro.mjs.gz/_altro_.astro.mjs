import { b as createAstro, c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsxs, jsx } from 'react/jsx-runtime';
import React, { useMemo } from 'react';
import styled from '@emotion/styled';
import { T as Theme, $ as $$Layout } from '../../../chunks/Layout_v259HEkx.mjs';
import '../../../chunks/next_CJC9ES1c.mjs';
export { renderers } from '../../../renderers.mjs';

const TableWrapper = styled.div`
  overflow-x: auto; overflow-y: auto; margin: 40px 0; align-self: center;
`;
const Table = styled.table`
  width: 100%;
  border-collapse: separate; border-spacing: 0;
  font-family: sans-serif;
  background: ${Theme.secondary};
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
  border-radius: 12px;
`;
const Th = styled.th`
  padding: 16px; font-weight: 600; text-transform: uppercase; text-align: center;
  background: ${Theme.secondary}; color: ${Theme.primary}; white-space: nowrap;
  &:first-of-type{ border-top-left-radius: 12px; }
  &:last-of-type{  border-top-right-radius: 12px; }
`;
const BodyRow = styled.tr`
  cursor: pointer;
  &:nth-of-type(odd){ background: #626262; }
`;
const Cell = styled.td`
  padding: 12px 16px;
  vertical-align: middle;  /* centro verticale */
  text-align: center;      /* centro orizzontale */
  font-variant-numeric: tabular-nums;
`;
const CellName = styled(Cell)`
min-width: 250px;
`;
const Badge = styled.span`
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-weight: 700; display: inline-block; min-width: 60px; text-align: center;
`;
styled.span`
  margin-left: 6px; padding: 2px 6px; border-radius: 8px; border: 1px solid ${Theme.primary};
  color: ${Theme.primary}; font-size: 10px; font-weight: 700;
`;
const Space = styled(Cell)`
width: 300px;
`;
const INVALID = /* @__PURE__ */ new Set(["DQ", "DNF", "DNS"]);
function parseTimeToMillis(inp, decimals = 2) {
  const raw = (inp || "").trim();
  if (!raw) return { valid: false, millis: null, display: "", status: "DNS" };
  const up = raw.toUpperCase();
  if (INVALID.has(up)) {
    const status = up;
    return { valid: false, millis: null, display: status, status };
  }
  const t = raw.replace(",", ".");
  const parts = t.split(":");
  let h = 0, m = 0, s = 0;
  if (parts.length === 1) {
    s = Number(parts[0]);
  } else if (parts.length === 2) {
    m = Number(parts[0]);
    s = Number(parts[1]);
  } else if (parts.length === 3) {
    h = Number(parts[0]);
    m = Number(parts[1]);
    s = Number(parts[2]);
  } else {
    return { valid: false, millis: null, display: raw, status: "OK" };
  }
  if (![h, m, s].every((n) => Number.isFinite(n))) {
    return { valid: false, millis: null, display: raw, status: "OK" };
  }
  const millis = Math.round((h * 3600 + m * 60 + s) * 1e3);
  const display = formatMillis(millis, decimals);
  return { valid: true, millis, display, status: "OK" };
}
function formatMillis(ms, decimals = 2) {
  const totalSeconds = ms / 1e3;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor(totalSeconds % 3600 / 60);
  const seconds = totalSeconds % 60;
  const secStr = seconds.toFixed(decimals).padStart(2 + (decimals ? decimals + 1 : 0), "0");
  if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${secStr}`;
  if (minutes > 0) return `${minutes}:${secStr.padStart(decimals ? 2 + 1 + decimals : 2, "0")}`;
  return secStr;
}
function compareResults(a, b) {
  if (a.valid && !b.valid) return -1;
  if (!a.valid && b.valid) return 1;
  if (!a.valid && !b.valid) {
    const order = (st) => st === "DQ" ? 2 : st === "DNF" ? 3 : 4;
    return order(a.status) - order(b.status);
  }
  return a.millis - b.millis;
}
function RacesTable({ event, data, decimals = 2, finals, atleta_squadra = true }) {
  const computed = useMemo(() => {
    const list = data.map((row) => {
      const parsed = parseTimeToMillis(row.time, decimals);
      const ev = { valid: parsed.valid, millis: parsed.millis, status: parsed.status };
      return { row, parsed, ev };
    });
    list.sort((A, B) => compareResults(A.ev, B.ev));
    return list.map((item, i, arr) => {
      const isTie = i > 0 && compareResults(arr[i - 1].ev, item.ev) === 0 && (arr[i - 1].ev.valid && item.ev.valid && arr[i - 1].ev.millis === item.ev.millis || !arr[i - 1].ev.valid && !item.ev.valid && arr[i - 1].ev.status === item.ev.status);
      const rank = isTie ? arr[i - 1]._rank : i + 1;
      item._rank = rank;
      return item;
    });
  }, [data, decimals]);
  return /* @__PURE__ */ jsxs(TableWrapper, { children: [
    event && /* @__PURE__ */ jsx("div", { style: { margin: "0px 0 10px 4px", color: "#94a3b8" }, children: event }),
    /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx(Th, { children: "#" }),
        /* @__PURE__ */ jsx(Th, { children: atleta_squadra ? "Atleta" : "Squadra" }),
        /* @__PURE__ */ jsx(Th, { children: "Scuola" }),
        /* @__PURE__ */ jsx(Th, { children: "Corsia" }),
        /* @__PURE__ */ jsx(Th, {}),
        /* @__PURE__ */ jsx(Th, { children: "Tempo" }),
        !finals && /* @__PURE__ */ jsx(Th, { children: "Q" })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: computed.map(({ row, parsed, _rank }) => {
        const timeDisplay = parsed.display || row.time;
        return /* @__PURE__ */ jsx(React.Fragment, { children: /* @__PURE__ */ jsxs(BodyRow, { children: [
          /* @__PURE__ */ jsx(Cell, { children: _rank }),
          /* @__PURE__ */ jsx(CellName, { children: row.athlete }),
          /* @__PURE__ */ jsx(Cell, { children: row.school ?? row.country ?? "" }),
          /* @__PURE__ */ jsx(Cell, { children: /* @__PURE__ */ jsx(Badge, { children: row.lane ?? "" }) }),
          /* @__PURE__ */ jsx(Space, {}),
          /* @__PURE__ */ jsx(Cell, { children: /* @__PURE__ */ jsx(Badge, { children: timeDisplay }) }),
          !finals && /* @__PURE__ */ jsx(Cell, { children: /* @__PURE__ */ jsx(Badge, { children: row.qualifier ? row.qualifier : "" }) })
        ] }) }, row.athlete);
      }) })
    ] })
  ] });
}

const nuoto_urls = [
  "do50M",
  "sl50M",
  "sl200M",
  "sl50F",
  "ra50M",
  "sl4x50"
];
const nuoto_to_title = {
  "do50M": "50m Dorso Maschile",
  "sl50M": "50m Stile Libero Maschile",
  "sl200M": "200m Stile Libero Maschile",
  "sl50F": "50m Stile Libero Femminile",
  "ra50M": "50m Rana Maschile",
  "sl4x50": "Staffetta 4x50m Stile Libero"
};

const getData = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  nuoto_to_title,
  nuoto_urls
}, Symbol.toStringTag, { value: 'Module' }));

const $$Astro = createAstro("https://riasissu.it");
async function getStaticPaths() {
  return nuoto_urls.map((altro) => ({
    params: { altro }
  }));
}
const $$altro = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$altro;
  const modules = /* #__PURE__ */ Object.assign({"/data/nuoto/do50M.ts": () => import('../../../chunks/do50M_CHGbDDX_.mjs'),"/data/nuoto/getData.ts": () => Promise.resolve().then(() => getData),"/data/nuoto/ra50M.ts": () => import('../../../chunks/ra50M_xaVhqwxn.mjs'),"/data/nuoto/sl200M.ts": () => import('../../../chunks/sl200M_BEYrm1Z6.mjs'),"/data/nuoto/sl4x50.ts": () => import('../../../chunks/sl4x50_DeS3R4pu.mjs'),"/data/nuoto/sl50F.ts": () => import('../../../chunks/sl50F_B4VSOmFO.mjs'),"/data/nuoto/sl50M.ts": () => import('../../../chunks/sl50M_48lIq1b1.mjs'),"/data/nuoto/sport.ts": () => import('../../../chunks/sport_RVbv3rgv.mjs')});
  const { altro } = Astro2.params;
  const path = `/data/nuoto/${altro}.ts`;
  const loader = modules[path];
  if (!loader) {
    throw Astro2.redirect("/404");
  }
  const mod = await loader();
  const data = mod.data ?? mod.default;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Medal standings for the XCOOL 2025 event." }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin:200px 0 50px 0px;">${nuoto_to_title[altro]}</h1></center> <!-- hydrate on load for interactivity --> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "", "data": data, "decimals": 2, "finals": true })} </div></center> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/nuoto/[altro].astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/nuoto/[altro].astro";
const $$url = "/xcool/tabelloni/nuoto/[altro]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$altro,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
