import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_BE-4ZxlD.mjs';
import 'kleur/colors';
import { B as BarChart } from '../../chunks/BarChart_DmhFcLgn.mjs';
import { $ as $$Layout } from '../../chunks/Layout_Abjf1cfq.mjs';
export { renderers } from '../../renderers.mjs';

const totals = [
  { school: "SSC", total: 74 },
  { school: "CSB", total: 17 },
  { school: "SSA", total: 0 },
  { school: "IUSS", total: 1 },
  { school: "ISUFI", total: 4 },
  { school: "SSSAS", total: 145 },
  { school: "SGSS", total: 111 },
  { school: "SSDTW", total: 143 },
  { school: "SSST", total: 77 },
  { school: "SSMC", total: 22 },
  { school: "SSUC", total: 0 }
];

const beer = new Proxy({"src":"/xcool/_astro/beer.DaduGdqG.webp","width":300,"height":300,"format":"webp"}, {
						get(target, name, receiver) {
							if (name === 'clone') {
								return structuredClone(target);
							}
							if (name === 'fsPath') {
								return "/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/beer.webp";
							}
							if (target[name] !== undefined && globalThis.astroAsset) globalThis.astroAsset?.referencedImages.add("/home/runner/work/xcool-webpage/xcool-webpage/src/static/images/beer.webp");
							return target[name];
						}
					});

const $$CoppaChiosco = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Medagliere per le XCOOL 2025." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin-top:200px;margin-bottom:50px;">Coppa Chiosco</h1></center> <div style="overflow:auto;"> ${renderComponent($$result2, "BarChart", BarChart, { "client:load": true, "data": totals, "icon": beer, "client:component-hydration": "load", "client:component-path": "@components/BarChart/BarChart.tsx", "client:component-export": "default" })} </div> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/coppa_chiosco.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/coppa_chiosco.astro";
const $$url = "/xcool/tabelloni/coppa_chiosco";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$CoppaChiosco,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
