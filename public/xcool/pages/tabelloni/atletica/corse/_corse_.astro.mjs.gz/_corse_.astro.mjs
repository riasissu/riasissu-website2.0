import { b as createAstro, c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../../../chunks/astro/server_BE-4ZxlD.mjs';
import 'kleur/colors';
import { R as RacesTable } from '../../../../chunks/RacesTable_DRgJ5Zve.mjs';
import { $ as $$Layout } from '../../../../chunks/Layout_Abjf1cfq.mjs';
import { c as corse_urls, d as corse_to_title } from '../../../../chunks/getData_BzIF5hIB.mjs';
export { renderers } from '../../../../renderers.mjs';

const $$Astro = createAstro("https://riasissu.it");
async function getStaticPaths() {
  return corse_urls.map((corse) => ({
    params: { corse }
  }));
}
const $$corse = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$corse;
  const { corse } = Astro2.params;
  const atleta_squadra = !corse.includes("x");
  const modules = /* #__PURE__ */ Object.assign({"/data/atletica/100mF_batterie.ts": () => import('../../../../chunks/100mF_batterie_D9GlbVm8.mjs'),"/data/atletica/100mF_batterie_old.ts": () => import('../../../../chunks/100mF_batterie_old_BlJooziK.mjs'),"/data/atletica/100mM_batterie.ts": () => import('../../../../chunks/100mM_batterie_DbG4B0T0.mjs'),"/data/atletica/100mM_finali.ts": () => import('../../../../chunks/100mM_finali_Ce9dxBWm.mjs'),"/data/atletica/1500mF.ts": () => import('../../../../chunks/1500mF_BX-XupF9.mjs'),"/data/atletica/1500mM.ts": () => import('../../../../chunks/1500mM_DIx2PXKc.mjs'),"/data/atletica/400mF.ts": () => import('../../../../chunks/400mF_KYyNhQtj.mjs'),"/data/atletica/400mM.ts": () => import('../../../../chunks/400mM_DlrpI79A.mjs'),"/data/atletica/4x100mF.ts": () => import('../../../../chunks/4x100mF_CYsCZLZd.mjs'),"/data/atletica/4x100mM_batterie.ts": () => import('../../../../chunks/4x100mM_batterie_BLh95WLj.mjs'),"/data/atletica/4x100mM_batterie_old.ts": () => import('../../../../chunks/4x100mM_batterie_old_8hzEYJXj.mjs'),"/data/atletica/4x400m.ts": () => import('../../../../chunks/4x400m_stqMOQb8.mjs'),"/data/atletica/5000mF.ts": () => import('../../../../chunks/5000mF_DGT6DvhQ.mjs'),"/data/atletica/5000mM.ts": () => import('../../../../chunks/5000mM_CMHIjuh9.mjs'),"/data/atletica/altoF.ts": () => import('../../../../chunks/altoF_DRB88UFD.mjs'),"/data/atletica/altoM.ts": () => import('../../../../chunks/altoM_vvgmho-y.mjs'),"/data/atletica/lungoF.ts": () => import('../../../../chunks/lungoF_BOpJMMIS.mjs'),"/data/atletica/lungoM.ts": () => import('../../../../chunks/lungoM_B9CRr2jp.mjs'),"/data/atletica/pesoF.ts": () => import('../../../../chunks/pesoF_DLz57RH2.mjs'),"/data/atletica/pesoM.ts": () => import('../../../../chunks/pesoM_DpWf93sE.mjs'),"/data/atletica/vortexF.ts": () => import('../../../../chunks/vortexF_CIkiO08-.mjs'),"/data/atletica/vortexM.ts": () => import('../../../../chunks/vortexM_BsjQGoJH.mjs')});
  const path = `/data/atletica/${corse}.ts`;
  const loader = modules[path];
  if (!loader) {
    throw Astro2.redirect("/404");
  }
  const mod = await loader();
  const data = mod.data ?? mod.default;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Medal standings for the XCOOL 2025 event." }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin:200px 0 50px 0px;">${corse_to_title[corse]}</h1></center> <!-- hydrate on load for interactivity --> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "", "data": data, "decimals": 2, "finals": true, "atleta_squadra": atleta_squadra })} </div></center> </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/[corse].astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/[corse].astro";
const $$url = "/xcool/tabelloni/atletica/corse/[corse]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$corse,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
