import { b as createAstro, c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../../../chunks/astro/server_BE-4ZxlD.mjs';
import 'kleur/colors';
import { R as RacesTable } from '../../../../chunks/RacesTable_DRgJ5Zve.mjs';
import { $ as $$Layout } from '../../../../chunks/Layout_Abjf1cfq.mjs';
export { renderers } from '../../../../renderers.mjs';

const $$Astro = createAstro("https://riasissu.it");
const $$4X100MMBatterie = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$4X100MMBatterie;
  const modules = /* #__PURE__ */ Object.assign({"/data/atletica/100mF_batterie.ts": () => import('../../../../chunks/100mF_batterie_BlJooziK.mjs'),"/data/atletica/100mF_finali.ts": () => import('../../../../chunks/100mF_finali_D9GlbVm8.mjs'),"/data/atletica/100mM_batterie.ts": () => import('../../../../chunks/100mM_batterie_Dt5NvVbd.mjs'),"/data/atletica/100mM_finali.ts": () => import('../../../../chunks/100mM_finali_Ce9dxBWm.mjs'),"/data/atletica/1500mF.ts": () => import('../../../../chunks/1500mF_DBLV7MxV.mjs'),"/data/atletica/1500mM.ts": () => import('../../../../chunks/1500mM_ST7cgR9B.mjs'),"/data/atletica/400mF.ts": () => import('../../../../chunks/400mF_KYyNhQtj.mjs'),"/data/atletica/400mM.ts": () => import('../../../../chunks/400mM_DlrpI79A.mjs'),"/data/atletica/4x100mF.ts": () => import('../../../../chunks/4x100mF_CAtedAu9.mjs'),"/data/atletica/4x100mM_batterie.ts": () => import('../../../../chunks/4x100mM_batterie_8hzEYJXj.mjs'),"/data/atletica/4x100mM_finali.ts": () => import('../../../../chunks/4x100mM_finali_DE6-YtM2.mjs'),"/data/atletica/4x400m.ts": () => import('../../../../chunks/4x400m_A6aJ0PD_.mjs'),"/data/atletica/5000mF.ts": () => import('../../../../chunks/5000mF_DGT6DvhQ.mjs'),"/data/atletica/5000mM.ts": () => import('../../../../chunks/5000mM_B1xKbkji.mjs'),"/data/atletica/altoF.ts": () => import('../../../../chunks/altoF_ZiYlSKGF.mjs'),"/data/atletica/altoM.ts": () => import('../../../../chunks/altoM_v4nCaFhX.mjs'),"/data/atletica/lungoF.ts": () => import('../../../../chunks/lungoF_3xO9WE_8.mjs'),"/data/atletica/lungoM.ts": () => import('../../../../chunks/lungoM_DM9-cEW2.mjs'),"/data/atletica/pesoF.ts": () => import('../../../../chunks/pesoF_D78Y-IQw.mjs'),"/data/atletica/pesoM.ts": () => import('../../../../chunks/pesoM_B22fNENp.mjs'),"/data/atletica/vortexF.ts": () => import('../../../../chunks/vortexF_V7rFpjlB.mjs'),"/data/atletica/vortexM.ts": () => import('../../../../chunks/vortexM_BVuS0sxt.mjs')});
  const path = `/data/atletica/4x100mM_batterie.ts`;
  const loader = modules[path];
  if (!loader) {
    throw Astro2.redirect("/404");
  }
  const mod = await loader();
  const data1 = mod.data1 ?? mod.default;
  const data2 = mod.data2 ?? mod.default;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Medal standings for the XCOOL 2025 event." }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin:200px 0 50px 0px;">100m piani Maschile - Batterie</h1></center> <!-- hydrate on load for interactivity --> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 1", "data": data1, "decimals": 2, "finals": false, "atleta_squadra": false })} </div></center> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 2", "data": data2, "decimals": 2, "finals": false, "atleta_squadra": false })} </div></center> </main>` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/4x100mM_batterie.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/4x100mM_batterie.astro";
const $$url = "/xcool/tabelloni/atletica/corse/4x100mM_batterie";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$4X100MMBatterie,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
