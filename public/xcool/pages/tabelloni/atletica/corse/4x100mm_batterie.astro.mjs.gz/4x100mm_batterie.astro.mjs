import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { R as RacesTable } from '../../../../chunks/RacesTable_BkFoiLX5.mjs';
import { $ as $$Layout } from '../../../../chunks/Layout_B_i1K6gz.mjs';
import { data1, data2 } from '../../../../chunks/4x100mM_batterie_8hzEYJXj.mjs';
export { renderers } from '../../../../renderers.mjs';

const $$4X100MMBatterie = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Medal standings for the XCOOL 2025 event." }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center><h1 style="margin:200px 0 50px 0px;">100m piani Maschile - Batterie</h1></center> <!-- hydrate on load for interactivity --> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 1", "data": data1, "decimals": 2, "finals": false })} </div></center> <center><div style="margin: 0 10px 0 10px; max-width:960px; overflow:auto"> ${renderComponent($$result2, "RacesTable", RacesTable, { "event": "Batteria 2", "data": data2, "decimals": 2, "finals": false })} </div></center> </main>` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/4x100mM_batterie.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/corse/4x100mM_batterie.astro";
const $$url = "/xcool/tabelloni/atletica/corse/4x100mM_batterie";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$4X100MMBatterie,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
