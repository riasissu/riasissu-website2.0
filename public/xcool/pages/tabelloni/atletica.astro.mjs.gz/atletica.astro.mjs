import { c as createComponent, r as renderComponent, a as renderTemplate, m as maybeRenderHead } from '../../chunks/astro/server_DOuRIHWv.mjs';
import 'kleur/colors';
import 'html-escaper';
import { jsx, jsxs } from 'react/jsx-runtime';
import 'react';
import styled from '@emotion/styled';
import { T as Theme, M as MediaQuery, $ as $$Layout } from '../../chunks/Layout_v259HEkx.mjs';
import { cards } from '../../chunks/sport_DRUAvGG4.mjs';
import { F as FadeIn } from '../../chunks/FadeIn_BcXnD14c.mjs';
export { renderers } from '../../renderers.mjs';

const PageWrapper = styled.div`
  padding: 40px;
  background: ${Theme.secondary};
`;
const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 24px;

  ${MediaQuery.max("md")} {
    grid-template-columns: 1fr;
  }
`;
const CardLink = styled.a`
  display: block;
  text-decoration: none;
  color: inherit;
  border-radius: 12px;
  overflow: hidden;
  max-width: 875px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  transition: transform 0.3s, box-shadow 0.3s;
  border-color: #94a3b87d;
  border-style: solid;
  border-width: 0.5px;
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(255, 255, 255, 0.15);
  }
`;
const CardImage = styled.img`
  width: 100%;
  height: 160px;
  object-fit: cover;
`;
const CardContent = styled.div`
  padding: 16px;
  background: ${Theme.secondary};
`;
const CardTitle = styled.h3`
  margin: 0 0 8px;
  font-size: 20px;
  line-height: 1.2;
  color: ${Theme.primary};
`;
const CardDescription = styled.div`
  margin: 2px;
  font-size: 14px;
  color: #cbcacd;
`;
const CardGallery = () => /* @__PURE__ */ jsx(FadeIn, { children: /* @__PURE__ */ jsx(PageWrapper, { children: /* @__PURE__ */ jsx(Grid, { children: cards.map((c) => {
  const priority = c.title == "Salto in Alto Maschile" ? "high" : "auto";
  return /* @__PURE__ */ jsxs(CardLink, { href: c.href, children: [
    /* @__PURE__ */ jsx(CardImage, { src: c.imgSrc, alt: c.title, fetchPriority: priority }),
    /* @__PURE__ */ jsxs(CardContent, { children: [
      /* @__PURE__ */ jsx(CardTitle, { children: c.title }),
      /* @__PURE__ */ jsxs(CardDescription, { children: [
        /* @__PURE__ */ jsx("strong", { children: "Partecipanti: " }),
        c.participants
      ] })
    ] })
  ] }, c.href);
}) }) }) });

const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "XCOOL 2025", "description": "Evento organizzato dalla Scuola Superiore Di Toppo Wassermann in collaborazione con RIASISSU", "headerClass": "custom-bg" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="page-content info-page page-404"> <center> <h1 class="page-title" style="margin-top: 200px;">Atletica</h1> </center> ${renderComponent($$result2, "CardGallery", CardGallery, { "client:load": true, "client:component-hydration": "load", "client:component-path": "@components/AthleticsModules/CardGallery", "client:component-export": "default" })} </main> ` })}`;
}, "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/index.astro", void 0);

const $$file = "/home/runner/work/xcool-webpage/xcool-webpage/src/pages/tabelloni/atletica/index.astro";
const $$url = "/xcool/tabelloni/atletica";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
